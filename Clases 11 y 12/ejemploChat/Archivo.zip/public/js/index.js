const socket = io()

function mostrarMensajes(mensajes) {
    console.log(mensajes)

    const mensajesParaMostrar = mensajes.map(({ fecha, autor, texto }) => {
        return `${fecha} - ${autor}: ${texto}`
    })

    console.log(mensajesParaMostrar)
}

socket.on('mensajesActualizados', mensajes => {
   mostrarMensajes(mensajes)
})

const botonEnviar = document.getElementById('botonEnviar')
botonEnviar.addEventListener('click', e => {
    const inputAutor = document.getElementById('inputAutor')
    const inputMensaje = document.getElementById('inputMensaje')
    if(inputAutor.value && inputMensaje.value){
        const mensaje = {
            autor: inputAutor.value,
            texto: inputMensaje.value
        }
        socket.emit('nuevoMensaje', mensaje)
    } else {
        alert('ingresar mensaje')
    }
})